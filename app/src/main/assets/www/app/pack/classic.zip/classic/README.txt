CLASSIC SESSIONS
================

The every-day sessions the page has always shipped: gamma, beta, alpha, theta, delta, Schumann and isochronic pulses, plus the hand-built focus-level set (Focus 3, 10, 12, 15, 21, 27 and the long level tour).

Contents: 15 presets, about 521 minutes of material in total.

HOW TO ADD THEM
---------------
Gnaural (desktop, Windows/Linux): the program opens any .gnaural file directly
  (File > Open, or drag it onto the window). On Linux the default working file
  lives in ~/.gnaural/ if you want them waiting there.
Gnaural Web (the music hub at moddys.net): open the app and drop the .zip on the
  page (Add pack), or use "Open .gnaural..." for a single file. Imported packs
  stay in your browser until you remove them.
Any other Gnaural-compatible tool: these are plain XML files in the documented
  format (gnauralfile_version 1.20101006).

ABOUT THE FOCUS-LEVEL SETS
--------------------------
The focus-level sessions are original tone schedules inspired by the publicly
documented focus-level tone sets of the Monroe Institute's Gateway programme -
independent measurements, republished since the 1990s, of layered carrier[beat]
pairs (a notation like 503[4.2] means a 4.2 Hz beat between two carriers equally
separated from 503 Hz). They reproduce a documented frequency architecture only:
no audio, narration, scripts or printed material from those recordings is
included, and this pack is not affiliated with, endorsed by or supported by the
Monroe Institute.

WHAT THE WAVES ARE
------------------
The wave packs follow the level arc of that published programme: wave I works
focus 3 into focus 10, wave II adds the focus-12 tools, waves III and IV stay in
the 10-12 band, wave V moves to focus 15 ("no time"), wave VI to focus 21 ("the
bridge") and wave VII reaches focus 27. In the source programme each wave is an
album of six guided exercises used in sequence, and each album builds on the
tools of the one before it. These packs keep the level sequence and drop the
guidance - what remains is the tone architecture, so the schedule carries the
sitting instead of a voice.

SESSION LENGTHS
---------------
A full sitting here is 37 minutes, inside the 30-45 minute band that the source
programme's own usage notes ask you to set aside (its measured tracks typically
run 34-38 minutes). A first pass is deliberately short at 13 minutes, naps are
23, and the unguided free-flow sittings run 95 minutes by design. Longer is not
better - pick by the time you actually have.

THE NOISE BED
-------------
The bed under these sessions is pink noise, which is the documented convention
for this kind of programme: its manuals answer the "hissing sound" question by
explaining the pink-sound bed (and warn against noise-reduction processing),
and a Hemi-Sync-published study describes the bed as pink noise uniform from
40 to 320 Hz with a 12 dB/octave rolloff, with the carrier tones sitting about
15 dB above it. In these packs the bed sits 12-18 dB under the carrier layers
(about 14 dB for a typical layer - computed from the volumes in the files), the
same relationship. Surf-style sound belongs to the introduction of the source
material, not to the sessions.

THE RETURN SIGNAL
-----------------
Sessions that bring you back up end with a second, quieter carrier pair: around
281 Hz carrying a ~22 Hz beat. That is the return-to-waking signal measured at
the tail of the source exercises (281.20 + 22.00 Hz), reproduced here as an
original part of our own schedules. Sessions designed to fade into sleep do not
carry it.

WHERE THE SOURCES DISAGREE
--------------------------
The published tone sets exist in a few variants. This pack states what it uses:
focus 21 here is the "sometimes" reading (250/300 Hz at a 5.4 Hz beat) plus the
900[16.2] layer every published variant of that level carries; focus 27 is the
second measurement's set (with the 50 Hz layer); levels 23-26 come from the
second measurement lineage. All of the published sets for 22-27 trace back to a
single analyst's reading - no independent second measurement of 23-26 was found.
Focus 22 is described as identical to focus 21 in every source, so no separate
session is offered for it. Where sources disagree on a level used here, the
blurb says which reading it came from.

A NOTE ON SCOPE
---------------
Nothing here is a claim about what any level "does": the higher focus numbers
are belief-system material in the source tradition, and these files only
reproduce the published tone architecture.

HOW PEOPLE USE THEM
-------------------
In the source programme the exercises are worked through in order, and its own
notes give "one exercise a day for a week or a month" as an example pace while
saying outright that there are no rules - move on when it is familiar, and come
back when you want. The wave packs are arranged in that order. Sit or lie
somewhere you will not be disturbed, use headphones (the beat exists between
your ears - mono playback destroys it, and lossy encoders should be kept in
full stereo), set the volume low - the source notes say too low is better than
too high, deliberately, and volumes in the source material vary on purpose -
and give it an hour after eating; skip alcohol, drugs and excess caffeine; do
not listen while driving. Anyone with a seizure tendency or an auditory
disorder should talk to a doctor before using binaural tones.

Headphones are required for the binaural sessions - the beat exists between your
ears, not in the air. Isochronic sessions work on speakers. This is not a medical
device or a treatment.

FILE LIST
---------
  Calm Clarity (alpha).gnaural  -  1 voice, 21 min
  Deep Work (beta).gnaural  -  1 voice, 31 min
  Delta Sleep (2.5 Hz).gnaural  -  1 voice, 60 min
  Focus 10 - Mind Awake, Body Asleep.gnaural  -  5 voices, 37 min
  Focus 12 - Expanded Awareness.gnaural  -  7 voices, 36 min
  Focus 15 - No Time.gnaural  -  8 voices, 42 min
  Focus 21 - The Bridge.gnaural  -  7 voices, 42 min
  Focus 27 - Deep Stillness.gnaural  -  7 voices, 42 min
  Focus 3 - Orientation (resonant tuning).gnaural  -  3 voices, 25 min
  Focus 40 (gamma).gnaural  -  2 voices, 21 min
  Iso Pulse Focus (10 Hz).gnaural  -  1 voice, 16 min
  Level Tour - through the levels.gnaural  -  7 voices, 62 min
  Meditation (Schumann).gnaural  -  2 voices, 31 min
  Reset Break (16 to 10 Hz).gnaural  -  1 voice, 10 min
  Theta Drift (6 to 4 Hz).gnaural  -  1 voice, 45 min

PACK CONTENTS (sha256 of each file)
  2a9055c3990f6a1d6bfcdd6e3a61e909729e24242855be4518db54b38ee4b7ea  Focus 40 (gamma).gnaural
  150f584da185aeca860010e2eb39bd65e09126b94519fca9153778e36cef19ff  Deep Work (beta).gnaural
  beb6a2f2df8d1f7ede795fa16fa966dcdd6f931f482e954e8aeabede204d769f  Calm Clarity (alpha).gnaural
  36308c3965ed0ae90a2c34ab5e36aff6ebe0a1d7432b70c7460e2295d0094c22  Meditation (Schumann).gnaural
  c025a772f9b9356766f7065959a35e1e8cbce684a4bd5cc7a336603111470638  Theta Drift (6 to 4 Hz).gnaural
  550072646ece3a38380150e4884f9f90498b185bdc26e85f1250d3bed0a33a79  Delta Sleep (2.5 Hz).gnaural
  45aeda7cf0f3675506286bd596c3caacaf95816f27543a246495ff5a9631a209  Reset Break (16 to 10 Hz).gnaural
  d1a49d413e2dbb5a53d9e1e417b6299537789a3f05d83f10c653191df42d473e  Iso Pulse Focus (10 Hz).gnaural
  27519376d5cb19d66615b6935d76ab1e6142f25806699fafd00110617133b81c  Focus 3 - Orientation (resonant tuning).gnaural
  ac8e06e77c1d98798846293c9bdfd9e3af4bb51cac75aea67c850c5bb6d7288b  Focus 10 - Mind Awake, Body Asleep.gnaural
  8d6502b6fc8ad8610cabd9e797bc8c9c98e2a02a64e2fcfaa2885f99cacf5ba9  Focus 12 - Expanded Awareness.gnaural
  5032a171d3885132a8a0f2dde24953513d5873c4b7525db80afab5775ab810d2  Focus 15 - No Time.gnaural
  b18eba8f54a7d2f8242980cce9a14e5f8faef81beeec2fe785724e3b553d4db0  Focus 21 - The Bridge.gnaural
  317a2abe58d540157f921854e22b964df6134504ff52fb82464f390fc413f381  Focus 27 - Deep Stillness.gnaural
  bebf185aed6a3dc955ae12a9886ec149717f3984ab2d26ecb7af1615d5ec8ee4  Level Tour - through the levels.gnaural

LICENCE
-------
These preset files are original work packaged for the Gnaural Web app and are
licensed GPL-2.0-or-later, the same terms as the app's page code (the app's
engine port is LGPL-2.1-or-later; see its NOTICE.txt). The .gnaural format itself
belongs to Gnaural (c) Bret Logan and contributors. No upstream Gnaural preset
files are included - that library states no licence, so it is not redistributed.

Pack: classic.zip  -  generated by tools/gnaural_pack.js.
Rebuilds of the same library are byte-identical (sorted entries, pinned timestamps).
