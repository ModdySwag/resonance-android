SCHUMANN RESONANCES
===================

The measured resonances of the Earth–ionosphere cavity — the 7.83 Hz fundamental and the harmonics around 14.3, 20.8, 27.3 and 33.8 Hz — as tone sets in headphone and speaker versions; they are electromagnetic properties of the atmosphere rather than of a brain, and the audio here is only a representation of them.

Contents: 8 presets, about 315 minutes of material in total.

HOW TO ADD THEM
---------------
Gnaural (desktop, Windows/Linux): the program opens any .gnaural file directly
  (File > Open, or drag it onto the window). On Linux the default working file
  lives in ~/.gnaural/ if you want them waiting there.
Gnaural Web (the music hub at moddys.net): open the app and drop the .zip on the
  page (Add pack), or use "Open .gnaural..." for a single file. Imported packs
  stay in your browser until you remove them.
Any other Gnaural-compatible tool: these are plain XML files in the documented
  format (gnauralfile_version 1.20101006).

ABOUT THE FOCUS-LEVEL SETS
--------------------------
The focus-level sessions are original tone schedules inspired by the publicly
documented focus-level tone sets of the Monroe Institute's Gateway programme -
independent measurements, republished since the 1990s, of layered carrier[beat]
pairs (a notation like 503[4.2] means a 4.2 Hz beat between two carriers equally
separated from 503 Hz). They reproduce a documented frequency architecture only:
no audio, narration, scripts or printed material from those recordings is
included, and this pack is not affiliated with, endorsed by or supported by the
Monroe Institute.

WHAT THE WAVES ARE
------------------
The wave packs follow the level arc of that published programme: wave I works
focus 3 into focus 10, wave II adds the focus-12 tools, waves III and IV stay in
the 10-12 band, wave V moves to focus 15 ("no time"), wave VI to focus 21 ("the
bridge") and wave VII reaches focus 27. In the source programme each wave is an
album of six guided exercises used in sequence, and each album builds on the
tools of the one before it. These packs keep the level sequence and drop the
guidance - what remains is the tone architecture, so the schedule carries the
sitting instead of a voice.

SESSION LENGTHS
---------------
A full sitting here is 37 minutes, inside the 30-45 minute band that the source
programme's own usage notes ask you to set aside (its measured tracks typically
run 34-38 minutes). A first pass is deliberately short at 13 minutes, naps are
23, and the unguided free-flow sittings run 95 minutes by design. Longer is not
better - pick by the time you actually have.

THE NOISE BED
-------------
The bed under these sessions is pink noise, which is the documented convention
for this kind of programme: its manuals answer the "hissing sound" question by
explaining the pink-sound bed (and warn against noise-reduction processing),
and a Hemi-Sync-published study describes the bed as pink noise uniform from
40 to 320 Hz with a 12 dB/octave rolloff, with the carrier tones sitting about
15 dB above it. In these packs the bed sits 12-18 dB under the carrier layers
(about 14 dB for a typical layer - computed from the volumes in the files), the
same relationship. Surf-style sound belongs to the introduction of the source
material, not to the sessions.

THE RETURN SIGNAL
-----------------
Sessions that bring you back up end with a second, quieter carrier pair: around
281 Hz carrying a ~22 Hz beat. That is the return-to-waking signal measured at
the tail of the source exercises (281.20 + 22.00 Hz), reproduced here as an
original part of our own schedules. Sessions designed to fade into sleep do not
carry it.

WHERE THE SOURCES DISAGREE
--------------------------
The published tone sets exist in a few variants. This pack states what it uses:
focus 21 here is the "sometimes" reading (250/300 Hz at a 5.4 Hz beat) plus the
900[16.2] layer every published variant of that level carries; focus 27 is the
second measurement's set (with the 50 Hz layer); levels 23-26 come from the
second measurement lineage. All of the published sets for 22-27 trace back to a
single analyst's reading - no independent second measurement of 23-26 was found.
Focus 22 is described as identical to focus 21 in every source, so no separate
session is offered for it. Where sources disagree on a level used here, the
blurb says which reading it came from.

A NOTE ON SCOPE
---------------
Nothing here is a claim about what any level "does": the higher focus numbers
are belief-system material in the source tradition, and these files only
reproduce the published tone architecture.

HOW PEOPLE USE THEM
-------------------
In the source programme the exercises are worked through in order, and its own
notes give "one exercise a day for a week or a month" as an example pace while
saying outright that there are no rules - move on when it is familiar, and come
back when you want. The wave packs are arranged in that order. Sit or lie
somewhere you will not be disturbed, use headphones (the beat exists between
your ears - mono playback destroys it, and lossy encoders should be kept in
full stereo), set the volume low - the source notes say too low is better than
too high, deliberately, and volumes in the source material vary on purpose -
and give it an hour after eating; skip alcohol, drugs and excess caffeine; do
not listen while driving. Anyone with a seizure tendency or an auditory
disorder should talk to a doctor before using binaural tones.

Headphones are required for the binaural sessions - the beat exists between your
ears, not in the air. Isochronic sessions work on speakers. This is not a medical
device or a treatment.

FILE LIST
---------
  First pass - the 7.83 Hz fundamental.gnaural  -  2 voices, 13 min
  Fundamental and the 14.3 Hz harmonic.gnaural  -  3 voices, 38 min
  Monaural - 100 + 107.83 Hz (no headphones needed).gnaural  -  2 voices, 38 min
  The fundamental, down the long tail.gnaural  -  3 voices, 65 min
  The fundamental, held.gnaural  -  2 voices, 38 min
  The harmonics alone (14.3 to 33.8 Hz).gnaural  -  4 voices, 38 min
  The harmonics in the room (monaural pairs).gnaural  -  9 voices, 40 min
  The whole measured set.gnaural  -  7 voices, 45 min

PACK CONTENTS (sha256 of each file)
  d301a41c7b9bdb8febb235535bdf366dd4e52d1db570b12c71391a205a3c8257  First pass - the 7.83 Hz fundamental.gnaural
  7046f9707ad53dab769f656ab5d74c84155ec64bd81d124b783c0831ff2d97de  The fundamental, held.gnaural
  5f2eb6771f53acc6d5f0a67cc751f304f82afbf087d8d01656c569c15aa20927  Fundamental and the 14.3 Hz harmonic.gnaural
  c98b328fbb133718de1f80c2ba9c1b3022f16c7d93cbb99b52455923083c59fa  The harmonics alone (14.3 to 33.8 Hz).gnaural
  ed9b42d845b3b90d4307b93ff2db0aad0e265e6585e3b8c91919973f838700b9  The whole measured set.gnaural
  898bccdc064d36d4a699630e9719ac2a8f1f82fdd7f716eb07fff7ae0b5df89e  Monaural - 100 + 107.83 Hz (no headphones needed).gnaural
  160717b0515bbd70cba53d6b5154565b5559772764abe967a8423a51d7567e69  The harmonics in the room (monaural pairs).gnaural
  4dba1a0ee8021bf07678f93b5217b9aacda6bfbd290e78c4a3458d46a8d5d5b0  The fundamental, down the long tail.gnaural

LICENCE
-------
These preset files are original work packaged for the Gnaural Web app and are
licensed GPL-2.0-or-later, the same terms as the app's page code (the app's
engine port is LGPL-2.1-or-later; see its NOTICE.txt). The .gnaural format itself
belongs to Gnaural (c) Bret Logan and contributors. No upstream Gnaural preset
files are included - that library states no licence, so it is not redistributed.

Pack: schumann.zip  -  generated by tools/gnaural_pack.js.
Rebuilds of the same library are byte-identical (sorted entries, pinned timestamps).
