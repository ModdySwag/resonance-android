SPEAKERS — ISOCHRONIC ROOM SESSIONS
===================================

No headphones anywhere in this pack. Every layer is either a single-carrier pulse (isochronic) or a pair of steady carriers a few Hz apart that beat in the room itself, so one speaker or a stereo pair carries the whole thing — nothing here depends on a difference between your ears. Built for a living room: carriers in the range small speakers reproduce, quiet volumes you can talk over, nothing demanding a quiet room.

Contents: 9 presets, about 302 minutes of material in total.

HOW TO ADD THEM
---------------
Gnaural (desktop, Windows/Linux): the program opens any .gnaural file directly
  (File > Open, or drag it onto the window). On Linux the default working file
  lives in ~/.gnaural/ if you want them waiting there.
Gnaural Web (the music hub at moddys.net): open the app and drop the .zip on the
  page (Add pack), or use "Open .gnaural..." for a single file. Imported packs
  stay in your browser until you remove them.
Any other Gnaural-compatible tool: these are plain XML files in the documented
  format (gnauralfile_version 1.20101006).

SPEAKER USE (NO HEADPHONES IN THIS PACK)
----------------------------------------
Everything here is built for loudspeakers: one speaker, a pair, a soundbar or a
Bluetooth box. Nothing in this pack depends on a difference between your ears.

  * Binaural beats need headphones. A binaural file sends a slightly different
    frequency to each ear and the beat is created in your hearing - on speakers
    both ears hear both tones and the beat is gone. Clinical writing treats
    headphones as a requirement of the method (tones are presented dichotically
    "to guarantee that exposure to each of the two frequencies is restricted to
    one ear only" - Ingendoh et al., PLOS ONE 2023). No session here uses one,
    and that is asserted by this project's own tests, not just intended.
  * Isochronic (pulse) tones work anywhere. A single carrier is switched on and
    off at the session's rate, so the modulation is in the acoustic signal - the
    same stimulus class as the amplitude-modulated tones used in clinical
    auditory steady-state testing. That is most of the pack.
  * Monaural beats work on speakers too. "The acoustic beat" plays two steady
    carriers four cycles apart (200 and 204 Hz); the interference exists in the
    air of the room, not in your head. It is the one session with no pulses, and
    the closest thing to a beat a loudspeaker can actually produce.

PLACEMENT AND LEVEL
-------------------
  * Anywhere works. A stereo pair a couple of metres apart is ideal. A single
    speaker is just as valid - it removes the interference pattern between two
    sources entirely.
  * Move around: the pulse rate does not change with where you stand (that is
    the point of an isochronic session). What changes is loudness and tone
    colour, from room reflections - normal, and worse near a wall or a corner.
  * Volume: audible but conversational. The usual heuristic is the World Health
    Organization's: if you have to raise your voice to be heard at arm's length,
    it is too loud. Normal conversation is about 60 dB and levels stay under
    80 dB, where hearing damage becomes a concern over long exposure. Louder is
    not "more effect", just louder. (A pulse train also reads as more alerting
    than a steady tone at the same level, so err low.)
  * Carriers here sit between 200 and 500 Hz. Below that, small speakers roll
    off - and a room's own standing waves reach up to roughly 300 Hz, so a very
    low carrier is the one most likely to boom in one seat and vanish in
    another. A subwoofer does not help this material; skip it.
  * The pulses are a straight 50% on/off, the usual isochronic convention (there
    is, as far as we could find, no published study comparing duty cycles). The
    engine's pulse edges are about 2 ms; research gating practice uses ~5 ms
    cosine ramps. Nothing is claimed about the difference.
  * The noise beds are stereo (two independent noise streams, for width). In a
    mono fold-down - a single mono speaker or an OS downmix - the bed loses a
    few dB. The pulses and the acoustic beat are unaffected.
  * "Couch nap" ends with the same wake rate as the headphone naps in this
    library, rendered as a pulse so a speaker can carry it.

SAFETY
------
  * Not a medical device and not a treatment. Nothing here diagnoses, treats or
    prevents anything.
  * If you have epilepsy or a seizure disorder, ask a clinician before using
    repetitive pulsed tones. Whether audio pulses at these rates carry the same
    risk as visual flicker is not something we could find evidence for either
    way, so treat it as unknown rather than as safe.
  * Hearing: keep levels conversational (see above). Do not use this where you
    need to hear what is going on around you - traffic, doorbells, children.
  * Stop if it is unpleasant, gives you a headache, or leaves your ears ringing.

WHAT THIS IS BASED ON (AND WHAT IS NOT CLAIMED)
-----------------------------------------------
What is established: a periodic tone at rate R produces a measurable neural
response phase-locked to R in the auditory system while the sound is playing
(the frequency-following / auditory steady-state response), and that response
grows with level up to about 80 dB SPL (Bidelman & Powers 2018).
What is NOT established: that listening to a given rate durably changes your
brain state. The systematic review of 14 EEG studies found 5 in line with the
entrainment hypothesis, 8 contradictory and 1 mixed, and concluded there was
"no clear trend" either way (Ingendoh et al., PLOS ONE 2023). Claims about
focus, sleep, memory, anxiety or ADHD rest on that unverified premise. This
pack is a set of tone schedules for a room; it does not claim more than that.
The rate labels (a slow throb, six a second, ten, thirteen and a half) are
descriptive names for plain numbers, not medical categories.
Session lengths are convention, not an optimum: there is a five-minute session
and long background ones, and you should use whatever fits the room.

FILE LIST
---------
  Couch nap (pulse wake cue).gnaural  -  2 voices, 23 min
  Evening room (slow pulse).gnaural  -  1 voice, 38 min
  First pass - a quiet room pulse.gnaural  -  1 voice, 13 min
  Room theta (six a second).gnaural  -  3 voices, 45 min
  Settle the room (five minutes).gnaural  -  1 voice, 5 min
  Sit-anywhere focus (13.5 Hz).gnaural  -  2 voices, 38 min
  Slow slide (four into twelve).gnaural  -  2 voices, 64 min
  Talk-over alpha (very quiet).gnaural  -  2 voices, 38 min
  The acoustic beat (200 + 204 Hz).gnaural  -  2 voices, 38 min

PACK CONTENTS (sha256 of each file)
  8705f51cc7a3c2fc4113d6099101700b95a82b27eba155a3529dabd9c8f4f79b  First pass - a quiet room pulse.gnaural
  2341f4198b68892b3049abc1d9defbc4481d2963fbbb03938dd8860de1282c0c  Settle the room (five minutes).gnaural
  a74e9e25c7f532d5e9db3f902c67df4dd24296f3e3e616ddcc891bd3347d193c  Evening room (slow pulse).gnaural
  814b085d08f9b9a096d3e173122bbe7d902f32198a3ad770cabd979054700ffc  Talk-over alpha (very quiet).gnaural
  6ee6c18f7b2eb5d1b7cca5bb9f6c14f9187ab28eee5ed657aa23eff1b4447050  Sit-anywhere focus (13.5 Hz).gnaural
  464d3984013f33729816c903d72245beb7e552c3f95641f82566c9c75a2b08e8  Room theta (six a second).gnaural
  bb169b53b5db09faa931345e4a965cc48ada28151a856d72c0e317190a14b4a3  The acoustic beat (200 + 204 Hz).gnaural
  bf3f05b3bd2452d96717782ac432d962fa35d41da85b4c17d86ce84ac06f8e42  Slow slide (four into twelve).gnaural
  27c130ceb1d980833edd30a0bddfe349f1d4ea80606d5cfbfd5052a23fa357e7  Couch nap (pulse wake cue).gnaural

LICENCE
-------
These preset files are original work packaged for the Gnaural Web app and are
licensed GPL-2.0-or-later, the same terms as the app's page code (the app's
engine port is LGPL-2.1-or-later; see its NOTICE.txt). The .gnaural format itself
belongs to Gnaural (c) Bret Logan and contributors. No upstream Gnaural preset
files are included - that library states no licence, so it is not redistributed.

Pack: speakers.zip  -  generated by tools/gnaural_pack.js.
Rebuilds of the same library are byte-identical (sorted entries, pinned timestamps).
