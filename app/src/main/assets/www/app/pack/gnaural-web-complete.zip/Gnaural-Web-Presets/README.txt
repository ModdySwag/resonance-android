GNAURAL WEB - COMPLETE PRESET PACK
==================================

Every pack from the Gnaural Web tone generator at the moddys.net music hub, in
one archive: 18 packs, 124 presets, about 5535 minutes.

PACKS
-----
  Classic sessions/  -  15 presets, 521 min
  Wave I — F3 to F10/  -  7 presets, 311 min
  Wave II — F10 to F12/  -  6 presets, 189 min
  Wave III — F12/  -  5 presets, 292 min
  Wave IV — F12 to F15/  -  5 presets, 157 min
  Wave V — F15/  -  6 presets, 324 min
  Wave VI — F21/  -  6 presets, 215 min
  Wave VII — F21 to F27/  -  6 presets, 307 min
  Sleep & rest/  -  5 presets, 282 min
  Depth — F23 to F26/  -  6 presets, 210 min
  Speakers — isochronic room sessions/  -  9 presets, 302 min
  Tours/  -  4 presets, 208 min
  Schumann resonances/  -  8 presets, 315 min
  Breathing — six a minute/  -  8 presets, 331 min
  Solfeggio (the historical set)/  -  7 presets, 298 min
  Sleep ladder/  -  7 presets, 494 min
  Focus series (speaker pulses)/  -  8 presets, 297 min
  Deep listener (long tours)/  -  6 presets, 482 min

HOW TO ADD THEM
---------------
Gnaural (desktop, Windows/Linux): the program opens any .gnaural file directly
  (File > Open, or drag it onto the window). On Linux the default working file
  lives in ~/.gnaural/ if you want them waiting there.
Gnaural Web (the music hub at moddys.net): open the app and drop the .zip on the
  page (Add pack), or use "Open .gnaural..." for a single file. Imported packs
  stay in your browser until you remove them.
Any other Gnaural-compatible tool: these are plain XML files in the documented
  format (gnauralfile_version 1.20101006).

ABOUT THE FOCUS-LEVEL SETS
--------------------------
The focus-level sessions are original tone schedules inspired by the publicly
documented focus-level tone sets of the Monroe Institute's Gateway programme -
independent measurements, republished since the 1990s, of layered carrier[beat]
pairs (a notation like 503[4.2] means a 4.2 Hz beat between two carriers equally
separated from 503 Hz). They reproduce a documented frequency architecture only:
no audio, narration, scripts or printed material from those recordings is
included, and this pack is not affiliated with, endorsed by or supported by the
Monroe Institute.

WHAT THE WAVES ARE
------------------
The wave packs follow the level arc of that published programme: wave I works
focus 3 into focus 10, wave II adds the focus-12 tools, waves III and IV stay in
the 10-12 band, wave V moves to focus 15 ("no time"), wave VI to focus 21 ("the
bridge") and wave VII reaches focus 27. In the source programme each wave is an
album of six guided exercises used in sequence, and each album builds on the
tools of the one before it. These packs keep the level sequence and drop the
guidance - what remains is the tone architecture, so the schedule carries the
sitting instead of a voice.

SESSION LENGTHS
---------------
A full sitting here is 37 minutes, inside the 30-45 minute band that the source
programme's own usage notes ask you to set aside (its measured tracks typically
run 34-38 minutes). A first pass is deliberately short at 13 minutes, naps are
23, and the unguided free-flow sittings run 95 minutes by design. Longer is not
better - pick by the time you actually have.

THE NOISE BED
-------------
The bed under these sessions is pink noise, which is the documented convention
for this kind of programme: its manuals answer the "hissing sound" question by
explaining the pink-sound bed (and warn against noise-reduction processing),
and a Hemi-Sync-published study describes the bed as pink noise uniform from
40 to 320 Hz with a 12 dB/octave rolloff, with the carrier tones sitting about
15 dB above it. In these packs the bed sits 12-18 dB under the carrier layers
(about 14 dB for a typical layer - computed from the volumes in the files), the
same relationship. Surf-style sound belongs to the introduction of the source
material, not to the sessions.

THE RETURN SIGNAL
-----------------
Sessions that bring you back up end with a second, quieter carrier pair: around
281 Hz carrying a ~22 Hz beat. That is the return-to-waking signal measured at
the tail of the source exercises (281.20 + 22.00 Hz), reproduced here as an
original part of our own schedules. Sessions designed to fade into sleep do not
carry it.

WHERE THE SOURCES DISAGREE
--------------------------
The published tone sets exist in a few variants. This pack states what it uses:
focus 21 here is the "sometimes" reading (250/300 Hz at a 5.4 Hz beat) plus the
900[16.2] layer every published variant of that level carries; focus 27 is the
second measurement's set (with the 50 Hz layer); levels 23-26 come from the
second measurement lineage. All of the published sets for 22-27 trace back to a
single analyst's reading - no independent second measurement of 23-26 was found.
Focus 22 is described as identical to focus 21 in every source, so no separate
session is offered for it. Where sources disagree on a level used here, the
blurb says which reading it came from.

A NOTE ON SCOPE
---------------
Nothing here is a claim about what any level "does": the higher focus numbers
are belief-system material in the source tradition, and these files only
reproduce the published tone architecture.

HOW PEOPLE USE THEM
-------------------
In the source programme the exercises are worked through in order, and its own
notes give "one exercise a day for a week or a month" as an example pace while
saying outright that there are no rules - move on when it is familiar, and come
back when you want. The wave packs are arranged in that order. Sit or lie
somewhere you will not be disturbed, use headphones (the beat exists between
your ears - mono playback destroys it, and lossy encoders should be kept in
full stereo), set the volume low - the source notes say too low is better than
too high, deliberately, and volumes in the source material vary on purpose -
and give it an hour after eating; skip alcohol, drugs and excess caffeine; do
not listen while driving. Anyone with a seizure tendency or an auditory
disorder should talk to a doctor before using binaural tones.

Headphones are required for the binaural sessions - the beat exists between your
ears, not in the air. Isochronic sessions work on speakers. This is not a medical
device or a treatment.

SPEAKER USE (NO HEADPHONES IN THIS PACK)
----------------------------------------
Everything here is built for loudspeakers: one speaker, a pair, a soundbar or a
Bluetooth box. Nothing in this pack depends on a difference between your ears.

  * Binaural beats need headphones. A binaural file sends a slightly different
    frequency to each ear and the beat is created in your hearing - on speakers
    both ears hear both tones and the beat is gone. Clinical writing treats
    headphones as a requirement of the method (tones are presented dichotically
    "to guarantee that exposure to each of the two frequencies is restricted to
    one ear only" - Ingendoh et al., PLOS ONE 2023). No session here uses one,
    and that is asserted by this project's own tests, not just intended.
  * Isochronic (pulse) tones work anywhere. A single carrier is switched on and
    off at the session's rate, so the modulation is in the acoustic signal - the
    same stimulus class as the amplitude-modulated tones used in clinical
    auditory steady-state testing. That is most of the pack.
  * Monaural beats work on speakers too. "The acoustic beat" plays two steady
    carriers four cycles apart (200 and 204 Hz); the interference exists in the
    air of the room, not in your head. It is the one session with no pulses, and
    the closest thing to a beat a loudspeaker can actually produce.

PLACEMENT AND LEVEL
-------------------
  * Anywhere works. A stereo pair a couple of metres apart is ideal. A single
    speaker is just as valid - it removes the interference pattern between two
    sources entirely.
  * Move around: the pulse rate does not change with where you stand (that is
    the point of an isochronic session). What changes is loudness and tone
    colour, from room reflections - normal, and worse near a wall or a corner.
  * Volume: audible but conversational. The usual heuristic is the World Health
    Organization's: if you have to raise your voice to be heard at arm's length,
    it is too loud. Normal conversation is about 60 dB and levels stay under
    80 dB, where hearing damage becomes a concern over long exposure. Louder is
    not "more effect", just louder. (A pulse train also reads as more alerting
    than a steady tone at the same level, so err low.)
  * Carriers here sit between 200 and 500 Hz. Below that, small speakers roll
    off - and a room's own standing waves reach up to roughly 300 Hz, so a very
    low carrier is the one most likely to boom in one seat and vanish in
    another. A subwoofer does not help this material; skip it.
  * The pulses are a straight 50% on/off, the usual isochronic convention (there
    is, as far as we could find, no published study comparing duty cycles). The
    engine's pulse edges are about 2 ms; research gating practice uses ~5 ms
    cosine ramps. Nothing is claimed about the difference.
  * The noise beds are stereo (two independent noise streams, for width). In a
    mono fold-down - a single mono speaker or an OS downmix - the bed loses a
    few dB. The pulses and the acoustic beat are unaffected.
  * "Couch nap" ends with the same wake rate as the headphone naps in this
    library, rendered as a pulse so a speaker can carry it.

SAFETY
------
  * Not a medical device and not a treatment. Nothing here diagnoses, treats or
    prevents anything.
  * If you have epilepsy or a seizure disorder, ask a clinician before using
    repetitive pulsed tones. Whether audio pulses at these rates carry the same
    risk as visual flicker is not something we could find evidence for either
    way, so treat it as unknown rather than as safe.
  * Hearing: keep levels conversational (see above). Do not use this where you
    need to hear what is going on around you - traffic, doorbells, children.
  * Stop if it is unpleasant, gives you a headache, or leaves your ears ringing.

WHAT THIS IS BASED ON (AND WHAT IS NOT CLAIMED)
-----------------------------------------------
What is established: a periodic tone at rate R produces a measurable neural
response phase-locked to R in the auditory system while the sound is playing
(the frequency-following / auditory steady-state response), and that response
grows with level up to about 80 dB SPL (Bidelman & Powers 2018).
What is NOT established: that listening to a given rate durably changes your
brain state. The systematic review of 14 EEG studies found 5 in line with the
entrainment hypothesis, 8 contradictory and 1 mixed, and concluded there was
"no clear trend" either way (Ingendoh et al., PLOS ONE 2023). Claims about
focus, sleep, memory, anxiety or ADHD rest on that unverified premise. This
pack is a set of tone schedules for a room; it does not claim more than that.
The rate labels (a slow throb, six a second, ten, thirteen and a half) are
descriptive names for plain numbers, not medical categories.
Session lengths are convention, not an optimum: there is a five-minute session
and long background ones, and you should use whatever fits the room.

LICENCE
-------
These preset files are original work packaged for the Gnaural Web app and are
licensed GPL-2.0-or-later, the same terms as the app's page code (the app's
engine port is LGPL-2.1-or-later; see its NOTICE.txt). The .gnaural format itself
belongs to Gnaural (c) Bret Logan and contributors. No upstream Gnaural preset
files are included - that library states no licence, so it is not redistributed.

Generated 2026-09-28 by tools/gnaural_pack.js - byte-identical on rebuild.
