WAVE V — F15
============

Deeper into the no-time level: the still set in every shape — long, open, short, sleepy.

Contents: 6 presets, about 324 minutes of material in total.

HOW TO ADD THEM
---------------
Gnaural (desktop, Windows/Linux): the program opens any .gnaural file directly
  (File > Open, or drag it onto the window). On Linux the default working file
  lives in ~/.gnaural/ if you want them waiting there.
Gnaural Web (the music hub at moddys.net): open the app and drop the .zip on the
  page (Add pack), or use "Open .gnaural..." for a single file. Imported packs
  stay in your browser until you remove them.
Any other Gnaural-compatible tool: these are plain XML files in the documented
  format (gnauralfile_version 1.20101006).

ABOUT THE FOCUS-LEVEL SETS
--------------------------
The focus-level sessions are original tone schedules inspired by the publicly
documented focus-level tone sets of the Monroe Institute's Gateway programme -
independent measurements, republished since the 1990s, of layered carrier[beat]
pairs (a notation like 503[4.2] means a 4.2 Hz beat between two carriers equally
separated from 503 Hz). They reproduce a documented frequency architecture only:
no audio, narration, scripts or printed material from those recordings is
included, and this pack is not affiliated with, endorsed by or supported by the
Monroe Institute.

WHAT THE WAVES ARE
------------------
The wave packs follow the level arc of that published programme: wave I works
focus 3 into focus 10, wave II adds the focus-12 tools, waves III and IV stay in
the 10-12 band, wave V moves to focus 15 ("no time"), wave VI to focus 21 ("the
bridge") and wave VII reaches focus 27. In the source programme each wave is an
album of six guided exercises used in sequence, and each album builds on the
tools of the one before it. These packs keep the level sequence and drop the
guidance - what remains is the tone architecture, so the schedule carries the
sitting instead of a voice.

SESSION LENGTHS
---------------
A full sitting here is 37 minutes, inside the 30-45 minute band that the source
programme's own usage notes ask you to set aside (its measured tracks typically
run 34-38 minutes). A first pass is deliberately short at 13 minutes, naps are
23, and the unguided free-flow sittings run 95 minutes by design. Longer is not
better - pick by the time you actually have.

THE NOISE BED
-------------
The bed under these sessions is pink noise, which is the documented convention
for this kind of programme: its manuals answer the "hissing sound" question by
explaining the pink-sound bed (and warn against noise-reduction processing),
and a Hemi-Sync-published study describes the bed as pink noise uniform from
40 to 320 Hz with a 12 dB/octave rolloff, with the carrier tones sitting about
15 dB above it. In these packs the bed sits 12-18 dB under the carrier layers
(about 14 dB for a typical layer - computed from the volumes in the files), the
same relationship. Surf-style sound belongs to the introduction of the source
material, not to the sessions.

THE RETURN SIGNAL
-----------------
Sessions that bring you back up end with a second, quieter carrier pair: around
281 Hz carrying a ~22 Hz beat. That is the return-to-waking signal measured at
the tail of the source exercises (281.20 + 22.00 Hz), reproduced here as an
original part of our own schedules. Sessions designed to fade into sleep do not
carry it.

WHERE THE SOURCES DISAGREE
--------------------------
The published tone sets exist in a few variants. This pack states what it uses:
focus 21 here is the "sometimes" reading (250/300 Hz at a 5.4 Hz beat) plus the
900[16.2] layer every published variant of that level carries; focus 27 is the
second measurement's set (with the 50 Hz layer); levels 23-26 come from the
second measurement lineage. All of the published sets for 22-27 trace back to a
single analyst's reading - no independent second measurement of 23-26 was found.
Focus 22 is described as identical to focus 21 in every source, so no separate
session is offered for it. Where sources disagree on a level used here, the
blurb says which reading it came from.

A NOTE ON SCOPE
---------------
Nothing here is a claim about what any level "does": the higher focus numbers
are belief-system material in the source tradition, and these files only
reproduce the published tone architecture.

HOW PEOPLE USE THEM
-------------------
In the source programme the exercises are worked through in order, and its own
notes give "one exercise a day for a week or a month" as an example pace while
saying outright that there are no rules - move on when it is familiar, and come
back when you want. The wave packs are arranged in that order. Sit or lie
somewhere you will not be disturbed, use headphones (the beat exists between
your ears - mono playback destroys it, and lossy encoders should be kept in
full stereo), set the volume low - the source notes say too low is better than
too high, deliberately, and volumes in the source material vary on purpose -
and give it an hour after eating; skip alcohol, drugs and excess caffeine; do
not listen while driving. Anyone with a seizure tendency or an auditory
disorder should talk to a doctor before using binaural tones.

Headphones are required for the binaural sessions - the beat exists between your
ears, not in the air. Isochronic sessions work on speakers. This is not a medical
device or a treatment.

FILE LIST
---------
  Down and away (into sleep).gnaural  -  8 voices, 65 min
  Long still.gnaural  -  8 voices, 64 min
  Open still (free flow).gnaural  -  8 voices, 95 min
  Still nap (wake ramp).gnaural  -  8 voices, 23 min
  The still field.gnaural  -  8 voices, 45 min
  Walk - twelve into fifteen.gnaural  -  8 voices, 32 min

PACK CONTENTS (sha256 of each file)
  4e004aa63ebb98ba95ab991dd71632e2d9847c1db10f582fdab2521b47478311  The still field.gnaural
  e2662bc9943102136c4678704de281d8e5179e7efb857699597f4267d87b5859  Long still.gnaural
  8a5dafa0090188dff625be9031f039454b026a4c9cac806c019ddb4252d8a092  Open still (free flow).gnaural
  426dbf6910ac215d567219af897fac968d17b0c40a9403c70e930142c1d5753f  Still nap (wake ramp).gnaural
  c3a56d2e18e5b2dd2199336cb9e1a081821b3821b2e11bb1ac46f72823acf0e4  Down and away (into sleep).gnaural
  659f837a354a50ce993fe86592f370108619cbd471ad9518890b52a59a290d22  Walk - twelve into fifteen.gnaural

LICENCE
-------
These preset files are original work packaged for the Gnaural Web app and are
licensed GPL-2.0-or-later, the same terms as the app's page code (the app's
engine port is LGPL-2.1-or-later; see its NOTICE.txt). The .gnaural format itself
belongs to Gnaural (c) Bret Logan and contributors. No upstream Gnaural preset
files are included - that library states no licence, so it is not redistributed.

Pack: wave5.zip  -  generated by tools/gnaural_pack.js.
Rebuilds of the same library are byte-identical (sorted entries, pinned timestamps).
